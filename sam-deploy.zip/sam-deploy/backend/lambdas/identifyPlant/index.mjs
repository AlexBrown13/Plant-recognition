// index.mjs
// Node.js 18+
// IDENTIFY ONLY (no permanent saving)

export const handler = async (event) => {
  // ----- CORS preflight -----
  if (event.httpMethod === "OPTIONS") {
    return resp(200, {});
  }

  try {
    // ===== 1) read image (base64) =====
    let base64 = event.isBase64Encoded
      ? event.body
      : (event.imageBase64 ?? event.body);

    if (!base64) return resp(400, { error: "no image" });

    // allow raw base64 or data URL
    const raw = String(base64).replace(/^data:image\/\w+;base64,/, "");
    const imageBuffer = Buffer.from(raw, "base64");

    // ===== 2) PlantNet =====
    const form = new FormData();
    form.append(
      "images",
      new Blob([imageBuffer], { type: "image/jpeg" }),
      "plant.jpg"
    );

    const plantNetRes = await fetch(
      `https://my-api.plantnet.org/v2/identify/all?api-key=${process.env.PLANTNET_KEY}`,
      { method: "POST", body: form }
    );

    const plantNetJson = await plantNetRes.json();
    if (!plantNetRes.ok) {
      return resp(502, { error: "plantnet failed", plantNetJson });
    }

    const best = plantNetJson.results?.[0];
    if (!best) return resp(404, { error: "plant not identified" });

    const scientificName =
      best.species?.scientificNameWithoutAuthor ?? null;
    const commonName =
      best.species?.commonNames?.[0] ?? null;

    // ===== 3) Perenual: find id =====
    const sci2 = scientificName
      ?.split(" ")
      .slice(0, 2)
      .join(" ");

    const genus = scientificName?.split(" ")[0];

    const queries = [
      sci2,
      commonName,
      genus,
    ].filter(Boolean);

    let plant = null;

    for (const q of queries) {
      const listRes = await fetch(
        `https://perenual.com/api/v2/species-list?key=${process.env.PERENUAL_KEY}&q=${encodeURIComponent(q)}`
      );

      const listJson = await listRes.json();

      if (listRes.ok && listJson.data?.length) {
        plant = listJson.data[0];
        break;
      }
    }

    // If Perenual finds nothing, still return identification
    if (!plant) {
      return resp(200, {
        scientificName,
        commonName,
        perenualId: null,
        watering: "No care available",
        sunlight: ["No care available"],
      });
    }

    // ===== 4) Perenual: details (optional) =====
    let watering = "No care available";
    let sunlight = ["No care available"];

    try {
      const detailsRes = await fetch(
        `https://perenual.com/api/v2/species/details/${plant.id}?key=${process.env.PERENUAL_KEY}`
      );

      if (detailsRes.ok) {
        const details = await detailsRes.json();

        if (details?.watering) watering = details.watering;

        if (Array.isArray(details?.sunlight) && details.sunlight.length) {
          sunlight = details.sunlight;
        } else if (typeof details?.sunlight === "string" && details.sunlight.trim()) {
          sunlight = [details.sunlight.trim()];
        }
      }
    } catch {
      // ignore perenual errors
    }

    // ===== 5) response =====
    return resp(200, {
      scientificName,
      commonName,
      perenualId: plant.id,
      watering,
      sunlight,
    });

  } catch (e) {
    console.error(e);
    return resp(500, { error: "server error" });
  }
};

const resp = (statusCode, body) => ({
  statusCode,
  headers: {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Content-Type": "application/json",
  },
  body: JSON.stringify(body),
});
